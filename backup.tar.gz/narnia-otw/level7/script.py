#!/usr/bin/python

import struct 
import os
import sys

#0xf6fff2bc

print "6636666666666666"  
